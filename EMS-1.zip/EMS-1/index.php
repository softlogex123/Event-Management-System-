<?php
include 'common/db.php';

?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Home</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="assets/css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
  <!-- Navbar Code  -->
  <div class="">
    <nav class="navbar navbar-expand-lg custom-nav">
      <div class="container">
        <a class="navbar-brand" href="index.php">EMS</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav mx-auto">
            <li class="nav-item mx-2">
              <a class="nav-link active" aria-current="page" href="index.php">Home</a>
            </li>
            <li class="nav-item mx-2">
              <a class="nav-link" href="event.php">Events</a>
            </li>
            <li class="nav-item mx-2">
              <a class="nav-link" href="#">About Us</a>
            </li>
            <li class="nav-item mx-2">
              <a class="nav-link" href="contact.php">Contact Us</a>
            </li>
          </ul>
          <div class="">
            <a class="nav-link sign-up" href="sign-up.php">Sign Up</a>
          </div>
        </div>
      </div>
    </nav>
  </div>

  <!-- Carousel Code -->
  <div id="carouselExample" class="carousel slide">
    <div class="carousel-inner">
        <?php
                        $filter = "SELECT * FROM slider";
                        $result = mysqli_query($conn, $filter);
                        if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                                    
                    ?>
      <div class="carousel-item active">
        <img src="admin/img/slider/<?php echo $row['slide_img']; ?>" class="d-block w-100" alt="...">
      </div>
      
      <!--<div class="carousel-item">-->
      <!--  <img src="assets/img/img-2.jpg" class="d-block w-100" alt="...">-->
      <!--</div>-->
      <!--<div class="carousel-item">-->
      <!--  <img src="assets/img/img-3.jpg" class="d-block w-100" alt="...">-->
      <!--</div>-->
      <?php   }  }?> 
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>
  <section class="about-section">
    <div class="container my-5">
      <div class="row align-items-center">
        <div class="col-md-4">
          <div class="side-img">
            <img src="https://placehold.co/600x400" alt="about">
          </div>
        </div>
        <div class="col-md-8">
          <div class="side-content">
            <h5>About The Events</h5>
            <h1>Event And Seminar</h1>
            <p>My goal is to curate engaging events and seminars in Lahore, set against the backdrop of a specific, carefully chosen venue. These gatherings aim to foster knowledge sharing and vibrant discussions within the local community.</p>
            <div class="">
              <a href="#">Get Ticket</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- Recent Events -->
  <div class="container recent my-5">
    <div class="row">
      <h2 class="text-center py-3">Recent Events</h2>
      <ul class="nav nav-pills mb-3 justify-content-center" id="pills-tab" role="tablist">
        <li class="nav-item" role="presentation">
          <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">Upcoming Events</button>
        </li>
        <li class="nav-item" role="presentation">
          <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Active Events</button>
        </li>
        <li class="nav-item" role="presentation">
          <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">Successful Complete Events</button>
        </li>
        <li class="nav-item" role="presentation">
          <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact-again" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">More</button>
        </li>
      </ul>
      <div class="tab-content" id="pills-tabContent">
        <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0">
          <div class="container my-3">
              <?php
                        $filter = "SELECT * FROM recent_event";
                        $result = mysqli_query($conn, $filter);
                        if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                                    
                    ?>
            <div class="row p-3 pill-data">
              <div class="col-md-3">
                <div class="col-img">
                  <img src="admin/img/events/<?php echo $row['img']; ?>" alt="" class="img-fluid">
                </div>
              </div>
              <div class="col-md-9">
                <div class="col-pill-content">
                  <h1><?php echo $row['title']; ?></h1>
                  <p><?php echo $row['description']; ?></p>
                  <h3>Topics</h3>
                  <div class="check-points">
                    <span><i class="fa-solid fa-check"></i> &nbsp; <?php echo $row['topic']; ?></span>
                    <span><i class="fa-solid fa-date"></i> &nbsp; Date: <?php echo $row['date']; ?></span>
                  </div>
                </div>
              </div>
            </div>
            <?php   }  }?> 
          </div>
          <!--<div class="container my-3">-->
          <!--  <div class="row p-3 pill-data">-->
          <!--    <div class="col-md-3">-->
          <!--      <div class="col-img">-->
          <!--        <img src="assets/img/img-1.jpg" alt="" class="img-fluid">-->
          <!--      </div>-->
          <!--    </div>-->
          <!--    <div class="col-md-9">-->
          <!--      <div class="col-pill-content">-->
          <!--        <h1>Education Event</h1>-->
          <!--        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>-->
          <!--        <h3>Topics</h3>-->
          <!--        <div class="check-points">-->
          <!--          <span><i class="fa-solid fa-check"></i> &nbsp; Education</span>-->
          <!--          <span><i class="fa-solid fa-check"></i> &nbsp;Study</span>-->
          <!--          <span><i class="fa-solid fa-check"></i> &nbsp;Management</span>-->
          <!--        </div>-->
          <!--      </div>-->
          <!--    </div>-->
          <!--  </div>-->
          <!--</div>-->
          <!--<div class="container my-3">-->
          <!--  <div class="row p-3 pill-data">-->
          <!--    <div class="col-md-3">-->
          <!--      <div class="col-img">-->
          <!--        <img src="assets/img/img-1.jpg" alt="" class="img-fluid">-->
          <!--      </div>-->
          <!--    </div>-->
          <!--    <div class="col-md-9">-->
          <!--      <div class="col-pill-content">-->
          <!--        <h1>Education Event</h1>-->
          <!--        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>-->
          <!--        <h3>Topics</h3>-->
          <!--        <div class="check-points">-->
          <!--          <span><i class="fa-solid fa-check"></i> &nbsp; Education</span>-->
          <!--          <span><i class="fa-solid fa-check"></i> &nbsp;Study</span>-->
          <!--          <span><i class="fa-solid fa-check"></i> &nbsp;Management</span>-->
          <!--        </div>-->
          <!--      </div>-->
          <!--    </div>-->
          <!--  </div>-->
          <!--</div>-->
        </div>
        <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabindex="0">
          <div class="container my-3">
            <div class="row p-3 pill-data">
              <div class="col-md-3">
                <div class="col-img">
                  <img src="assets/img/img-2.jpg" alt="" class="img-fluid">
                </div>
              </div>
              <div class="col-md-9">
                <div class="col-pill-content">
                  <h1>Education Event</h1>
                  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                  <h3>Topics</h3>
                  <span><i class="fa-solid fa-check"></i> &nbsp; Education</span>
                  <span><i class="fa-solid fa-check"></i> &nbsp;Study</span>
                  <span><i class="fa-solid fa-check"></i> &nbsp;Management</span>
                </div>
              </div>
            </div>
          </div>
          <div class="container my-3">
            <div class="row p-3 pill-data">
              <div class="col-md-3">
                <div class="col-img">
                  <img src="assets/img/img-2.jpg" alt="" class="img-fluid">
                </div>
              </div>
              <div class="col-md-9">
                <div class="col-pill-content">
                  <h1>Education Event</h1>
                  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                  <h3>Topics</h3>
                  <span><i class="fa-solid fa-check"></i> &nbsp; Education</span>
                  <span><i class="fa-solid fa-check"></i> &nbsp;Study</span>
                  <span><i class="fa-solid fa-check"></i> &nbsp;Management</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab" tabindex="0">
          <div class="container my-3">
            <div class="row p-3 pill-data">
              <div class="col-md-3">
                <div class="col-img">
                  <img src="assets/img/img-3.jpg" alt="" class="img-fluid">
                </div>
              </div>
              <div class="col-md-9">
                <div class="col-pill-content">
                  <h1>Seminar</h1>
                  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                  <h3>Topics</h3>
                  <span><i class="fa-solid fa-check"></i> &nbsp; Sport</span>
                  <span><i class="fa-solid fa-check"></i> &nbsp;Study</span>
                  <span><i class="fa-solid fa-check"></i> &nbsp;Management</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="tab-pane fade" id="pills-contact-again" role="tabpanel" aria-labelledby="pills-disabled-tab" tabindex="0">No Result</div>
      </div>
    </div>
  </div>
  <!-- Collaborator Section -->
  <div class="container my-4" >
    <h1 class="text-center">Our Collaborator</h1>
    <div class="row">
      <div class="col-md-4">
        <div class="collab-card">
          <div class="collab-img">
            <img src="assets/img/minhaj-logo.png" alt="" class="img-fluid">
          </div>
          <h3>Minhaj University</h3>
        </div>
      </div>
      <div class="col-md-4">
        <div class="collab-card">
          <div class="collab-img">
            <img src="assets/img/pu-logo.png" alt="" class="img-fluid">
          </div>
          <h3>Punjab University</h3>
        </div>
      </div>
      <div class="col-md-4">
        <div class="collab-card">
          <div class="collab-img">
            <img src="assets/img/edu-logo.png" alt="" class="img-fluid">
          </div>
          <h3>Education University</h3>
        </div>
      </div>
    </div>
  </div>
  <!-- Event Galley -->
  <div class="container-fluid my-5">
    <h2 class="text-center mb-3">Events Gallery</h2>
    <div class="gallery">
        <?php
                        $filter = "SELECT * FROM gallery";
                        $result = mysqli_query($conn, $filter);
                        if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                                    
                    ?>
      <div class="gallery-item">
        <img src="admin/img/gallery/<?php echo $row['img']; ?>" alt="Image 1">
      </div>
      <?php   }  }?> 
      <!-- Add more gallery items for each image -->
    </div>

  </div>
  <!-- FOOTER -->
  <footer class="py-3">
    <div class="footer-content">
      <div class="web-title">
        <h1>EMS</h1>
      </div>
      <div class="footer-pages">
        <h4>Useful Links</h4>
        <a href="index.html">Home</a>
        <a href="event.html">Event</a>
        <a href="contact.html">Contact</a>
        <a href="About.html">About Us</a>
      </div>
      <div class="contact-num">
        <h4>Contact Info</h4>
        <p>+923345432258</p>
        <p>contact@ems.pk</p>
      </div>
    </div>
  </footer>













  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>