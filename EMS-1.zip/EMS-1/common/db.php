<?php 
	
$conn = mysqli_connect('localhost','root','','u882905131_minhaj') ;
        mysqli_select_db($conn,'u882905131_minhaj');
?>