<?php 

session_start();
if($_SESSION['admin_name']){
}else{    header("location: index.php");
}

      include 'common/header.php';
      include 'common/left-bar.php';
      include '../common/db.php';


?>


        <div class="container-fluid my-4">
            <div class="row">
                <h3>User Reports</h3>
            </div>
        </div>
            <!-- Organizer List -->
    <div class="container-fluid my-2">
        <div class="row">        
            <div class="col-12">
                <div class="bg-light rounded h-100 p-4">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Phone</th>
                                    <th scope="col">Report</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php

                                        $filter = "select * from contact";
                                        $result = mysqli_query($conn, $filter);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {

                                         ?>
                                <tr>
                                    <th scope="row"><?php echo $row['id']; ?></th>
                                    <td><?php echo $row['name']; ?></td>
                                    <td><?php echo $row['email']; ?></td>
                                    <td><?php echo $row['phone']; ?></td>
                                    <td><?php echo $row['report']; ?></td>
                                </tr>
                                <?php   } }?>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include('common/footer.php'); ?>