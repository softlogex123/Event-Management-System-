<?php include('../common/db.php');
session_start();
if($_SESSION['admin_name']){
}else{    header("location: index.php");}
include 'common/header.php';
include 'common/left-bar.php';


if (isset($_POST['submit'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    //$topic = implode(',', $_POST['topic']);
    $date = $_POST['date'];
    
$topic = $_POST['topic'];
$chk="";  
foreach($topic as $chk1)  
   {  
      $chk .= $chk1.",";  
   }  
    
    $filetemp = $_FILES['file_img']['tmp_name'];
    $filename = $_FILES['file_img']['name'];
    $filetype = $_FILES['file_img']['type'];
    
    $filepath = "img/events/".$filename;
    
    move_uploaded_file($filetemp,$filepath);
    
                
    $sql = "INSERT INTO `recent_event`(`title`, `description`, `topic`, `date`, `img`) VALUES ('$title','$description','$chk','$date', '$filename')";

    $result = $conn->query($sql);
    	
  
    if ($result == true) {
        echo "<script>alert('Recent Event added');location.href='add_recent_event.php';</script>";
    }
              
        
  else{
        echo "something wrong";
    }            
            

}


?>

    <div class="container-fluid my-2">
        <div class="row">
            <h1 class="text-center">Landing Page Content</h1>
        </div>
    </div>

    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12 col-xl-12">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Recent Event Form</h6>
                    <form method="POST" action="" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="event-img" class="form-label">Event Image</label>
                            <input type="file" class="form-control" name="file_img" required>
                        </div>
                        <div class="mb-3">
                            <label for="event-title" class="form-label">Event Title</label>
                            <input type="text" class="form-control" name="title" required>
                        </div>
                        <div class="mb-3">
                            <label for="event-title" class="form-label">Event Description</label>
                            <textarea name="description" class="form-control" required></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3 form-check">
                                    <input type="checkbox" name="topic[]" value="Sport" class="form-check-input" id="Sport">
                                    <label class="form-check-label" for="Sport">Sport</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3 form-check">
                                    <input type="checkbox" name="topic[]" value="Educational" class="form-check-input" id="Educational">
                                    <label class="form-check-label" for="Educational">Educational</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3 form-check">
                                    <input type="checkbox" name="topic[]" value="Management" class="form-check-input" id="Management">
                                    <label class="form-check-label" for="Management">Management</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3 form-check">
                                    <input type="checkbox" name="topic[]" value="conference" class="form-check-input" id="conference">
                                    <label class="form-check-label" for="conference">conference</label>
                                </div>
                            </div> 
                        </div>
                        <div class="mb-3 col-md-3">
                            <label class="form-label" for="event-date">Event Date</label>
                            <input type="date" name="date" class="form-control" required>
                        </div>
                        <div class="button">
                            <input type="submit" class="btn btn-primary" name="submit" value="Save Event"> 
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
            <div class="container-fluid my-2">
                <div class="row">
                    <div class="col-12">
                        <div class="bg-light rounded h-100 p-4">
                            <h6 class="mb-4">Recent Event List</h6>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">Sr.No</th>
                                            <th scope="col">Event Title</th>
                                            <th scope="col">Date</th>
                                            <th scope="col">Image</th>
                                            <th scope="col">Topic</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php

                                        $filter = "select * from recent_event";
                                        $result = mysqli_query($conn, $filter);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {

                                         ?>
                                        <tr>
                                            <th scope="row"><?php echo $row['id']; ?></th>
                                            <td><?php echo $row['title']; ?></td>
                                            <td><?php echo $row['date']; ?></td>
                                            <td><img src="img/events/<?php echo $row['img']; ?>" alt="slider-img" height="80" width="80"> </td>
                                            <td><?php echo $row['topic']; ?> </td>
                                            <td><a href="function.php?delete_recent_event_id=<?php echo $row['id']; ?>" > <button class="btn-add">Remove</button></a> </td>
                                        </tr>
                                        <?php   } }?>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <?php include('common/footer.php'); ?>