<?php include('../common/db.php');
session_start();
if($_SESSION['admin_name']){
}else{    header("location: index.php");}
include 'common/header.php';
include 'common/left-bar.php';


?>

<!DOCTYPE html>
<html lang="en">

            <!-- Sale & Revenue Start -->
            <div class="container-fluid pt-4 px-4" style="height: 450px;">
                <div class="row g-4">
                    <div class="col-sm-6 col-xl-4">
                        <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-line fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2">Active Events</p>
                                <h6 class="mb-0">30</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-4">
                        <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-bar fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2">Success Events</p>
                                <h6 class="mb-0">40</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-4">
                        <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-area fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2">Total Organizer</p>
                                <h6 class="mb-0">4</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Sale & Revenue End -->


            


<?php include('common/footer.php'); ?>