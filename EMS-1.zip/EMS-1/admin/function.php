<?php

include '../common/db.php';


if(isset($_GET['delete_slider_id'])){
$dlt_id = $_GET['delete_slider_id'];
    $sql = "delete from slider where id = '$dlt_id'";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        echo "<script>alert('Slider Image Successfully Deleted!'); location.href='add_slider.php';</script>";
    }
}

if(isset($_GET['delete_gallery_id'])){
$dlt_id = $_GET['delete_gallery_id'];
    $sql = "delete from gallery where id = '$dlt_id'";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        echo "<script>alert('Gallery Image Successfully Deleted!'); location.href='add_gallery.php';</script>";
    }
}

if(isset($_GET['delete_organizer_id'])){
$dlt_id = $_GET['delete_organizer_id'];
    $sql = "delete from organizer where id = '$dlt_id'";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        echo "<script>alert('Organizer Successfully Deleted!'); location.href='organizer-list.php';</script>";
    }
}


?>