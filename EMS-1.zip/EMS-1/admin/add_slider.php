<?php

session_start();
if($_SESSION['admin_name']){
}else{    header("location: index.php");
}

include 'common/header.php';
include 'common/left-bar.php';
include '../common/db.php';

if (isset($_POST['submit'])) {
    $slide_name = $_POST['slide_name'];
    
    $filetemp = $_FILES['file_img']['tmp_name'];
    $filename = $_FILES['file_img']['name'];
    $filetype = $_FILES['file_img']['type'];
    
    $filepath = "img/slider/".$filename;
    
    move_uploaded_file($filetemp,$filepath);
    
    
                
    $sql = "INSERT INTO `slider`(`slide_name`, `slide_img`) VALUES ('$slide_name', '$filename')";

    $result = $conn->query($sql);
    	
  
    if ($result == true) {
        echo "<script>alert('Slider Image added');location.href='add_slider.php';</script>";
    }
              
        
  else{
        echo "something wrong";
    }            
            

}

?>

<!-- Slider Images Add and Remove -->
            <div class="container-fluid my-2">
                <div class="row">
                    <h1 class="text-center">Landing Page Content</h1>
                    <div class="col-md-12">
                        <h2>Slider Images</h2>
                        <div class="col-sm-12 col-xl-12">
                        <form  method="POST" action="" enctype="multipart/form-data">    
                            <div class="bg-light rounded h-100 p-4">
                                <h6 class="mb-4">Upload Image Slider</h6>
                                <div class="mb-3">
                                    <label for="formFile" class="form-label">Slider Image</label>
                                    <input class="form-control" type="file" id="formFile" name="file_img" required>
                                </div>
                                <div class="mb-3">
                                    <label for="slider-img" class="form-label">Image Title</label>
                                    <input class="form-control" type="Text" id="slide_name" name="slide_name" required>
                                </div>
                                <div class="button">
                                  <input type="submit" class="btn-add" name="submit" value="Add Image"> 
                                </div>
                            </div>
                        </form>
                        </div>
                        <div class="table-responsive my-2">
                            <table class="table text-start align-middle table-bordered table-hover mb-0">
                                <thead>
                                    <tr class="text-dark">
                                        <th scope="col">Sr.No</th>
                                        <th scope="col">Images</th>
                                        <th scope="col">Title</th>
                                        <th scope="col">Remove</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php

                                        $filter = "select * from slider";
                                        $result = mysqli_query($conn, $filter);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {

                                         ?>
                                    <tr>
                                        <td><?php echo $row['id']; ?></td>
                                        <td><img src="img/slider/<?php echo $row['slide_img']; ?>" alt="slider-img" height="55" width="110"> </td>
                                        <td><?php echo $row['slide_name']; ?></td>
                                        <td><a href="function.php?delete_slider_id=<?php echo $row['id']; ?>" > <button class="btn-add">Remove</button></a> </td>
                                    </tr>
                                    <?php   } }?>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Slider img Upload End -->
            
<?php include('common/footer.php'); ?>