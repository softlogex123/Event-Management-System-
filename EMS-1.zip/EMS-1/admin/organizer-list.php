<?php

session_start();
if($_SESSION['admin_name']){
}else{    header("location: index.php");
}

include 'common/header.php';
include 'common/left-bar.php';
include '../common/db.php';

?>


            <!-- Sale & Revenue Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-6 col-xl-4">
                        <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-line fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2">Active Events</p>
                                <h6 class="mb-0">30</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-4">
                        <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-bar fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2">Success Events</p>
                                <h6 class="mb-0">40</h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-4">
                        <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                            <i class="fa fa-chart-area fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2">Total Organizer</p>
                                <h6 class="mb-0">4</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Sale & Revenue End -->

            <!-- Organizer List -->
            <div class="container-fluid my-4">
                <div class="row">
                    <div class="col-sm-12 col-xl-12">
                        <div class="bg-light rounded h-100 p-4">
                            <h6 class="mb-4">Organizer</h6>
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Phone No</th>
                                        <th scope="col">Password</th>
                                        <th scope="col">Remove</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php

                                        $filter = "select * from organizer";
                                        $result = mysqli_query($conn, $filter);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {

                                         ?>
                                    <tr>
                                        <th scope="row"><?php echo $row['id']; ?></th>
                                        <td><?php echo $row['admin_name']; ?></td>
                                        <td><?php echo $row['email']; ?></td>
                                        <td><?php echo $row['phone']; ?></td>
                                        <td><?php echo $row['password']; ?></td>
                                        <td><a href="function.php?delete_organizer_id=<?php echo $row['id']; ?>" > <button class="btn-add">Remove</button></a> </td>
                                    </tr>
                                    <?php   } }?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>







<?php include('common/footer.php'); ?>