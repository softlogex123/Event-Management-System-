<?php 

session_start();
if($_SESSION['admin_name']){
}else{    header("location: index.php");
}

      include 'common/header.php';
      include 'common/left-bar.php';
      include '../common/db.php';

if (isset($_POST['submit'])) {

    $filetemp = $_FILES['file_img']['tmp_name'];
    $filename = $_FILES['file_img']['name'];
    $filetype = $_FILES['file_img']['type'];
    
    $filepath = "img/gallery/".$filename;
    
    move_uploaded_file($filetemp,$filepath);
    
   
    
$sql = "INSERT INTO `gallery`(`img`) VALUES ('$filename')";

  $result = $conn->query($sql);

  if ($result == true) {
    echo "<script>alert('Gallery Image added');location.href='add_gallery.php';</script>";
  }
  else{
   echo "something wrong";
  }


	  }
     
?> 


<div class="container-fluid my-2">
        <div class="row">
            <h1 class="text-center">Landing Page Content</h1>
        </div>
    </div>

    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12 col-xl-12">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Add Gallery Images</h6>
                    <form method="POST" action="" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="event-img" class="form-label">Gallery Image</label>
                            <input type="file" class="form-control" name="file_img" required>
                        </div>
                        <div class="button">
                            <input type="submit" class="btn btn-primary" name="submit" value="Add Image"> 
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
            <div class="container-fluid my-2">
                <div class="row">
                    <div class="col-12">
                        <div class="bg-light rounded h-100 p-4">
                            <h6 class="mb-4">Gallery List</h6>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">Sr.No</th>
                                            <th scope="col">Image</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php

                                        $filter = "select * from gallery";
                                        $result = mysqli_query($conn, $filter);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {

                                         ?>
                                        <tr>
                                            <th scope="row"><?php echo $row['id']; ?></th>
                                            <td><img src="img/gallery/<?php echo $row['img']; ?>" alt="slider-img" height="100" width="100"></td>
                                            <td><a href="function.php?delete_gallery_id=<?php echo $row['id']; ?>" > <button class="btn-add">Remove</button></a> </td>
                                        </tr>
                                        <?php   } }?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <?php include('common/footer.php'); ?>
            
            
