<?php

    include 'common/db.php';
    
    

?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Event</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="assets/css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
  <!-- Navbar Code  -->
  <div class="">
    <nav class="navbar navbar-expand-lg custom-nav">
      <div class="container">
        <a class="navbar-brand" href="index.php">EMS</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav mx-auto">
            <li class="nav-item mx-2">
              <a class="nav-link active" href="index.php">Home</a>
            </li>
            <li class="nav-item mx-2">
              <a class="nav-link" href="event.php">Events</a>
            </li>
            <li class="nav-item mx-2">
              <a class="nav-link" href="#">About Us</a>
            </li>
            <li class="nav-item mx-2">
              <a class="nav-link" href="contact.php">Contact Us</a>
            </li>
          </ul>
          <div class="">
            <a class="nav-link sign-up" href="sign-up.php">Sign Up</a>
          </div>
        </div>
      </div>
    </nav>
  </div>
  
  
  <!-- event section -->
    <section class="event my-5 p-2 mb-3">
        <?php

            $filter = "select * from events";
            $result = mysqli_query($conn, $filter);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {

        ?>
      
    <div class="container event-block">
      <div class="row mt-3">
        <div class="col-md-6">  
        <h1 class="set-event-name-org"><?php echo $row['event_name']; ?></h1>
        <h2>Organizer Name: <?php echo $row['admin_name']; ?></h2>
        </div>
        <h4>Event Schedule</h4>
        <div class="col-md-6">
          <div class="event-date p-2">
            <h2>Event Start Date</h2>
            <span><?php echo $row['start_date']; ?></span>
            <span></span>
          </div>
        </div>
        <div class="col-md-6">
          <div class="event-date p-2">
            <h2>Event End Date</h2>
            <span><?php echo $row['end_date']; ?></span>
            <span></span>
          </div>
        </div>
        <div class="col-md-4">
          <div class="event-data pt-3 mt-2 mb-2">
            <span><img src="assets/img/normal-seat.png" alt="seat"> <?php echo $row['ava_seat']; ?> Seats Available</span>
            <span><img src="assets/img/basic-s.png" alt="seat"> Charges: <?php echo $row['basic_charge']; ?> Basic</span>
            <span><img src="assets/img/premium-s.png" alt="seat"> Charges: <?php echo $row['pre_charge']; ?> Premium</span>
          </div>
        </div>
        <div class="col-md-8">
          <div class="event-text-lines p-2 mt-2 mb-2">
            <p><?php echo $row['description']; ?></p>
          </div>
        </div>
        <div class="col-md-12">
          <img src="organizer/img/events/<?php echo $row['img']; ?>" alt="" class="img-fluid">
        </div>
        
        <div class="col-md-12 text-center mt-4">
          <!-- Button trigger modal -->
          <a class="apply-btn mb-2" href="apply-ticket.php?id=<?php echo $row['id']; ?>">Apply Ticket</a>

          <!-- Modal -->
          <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Ticket Detail</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                  <h2>Ticket Submission Form</h2>

                  <form action="process_form.php" method="post" enctype="multipart/form-data">
                    <!-- Username -->
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username" required><br>

                    <!-- Email -->
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required><br>

                    <!-- Phone Number -->
                    <label for="phone">Phone Number:</label>
                    <input type="tel" id="phone" name="phone" required><br>

                    <!-- Transaction ID -->
                    <label for="transaction_id">Transaction ID:</label>
                    <input type="text" id="transaction_id" name="transaction_id" required><br>

                    <!-- Transaction Receipt Image Upload -->
                    <label for="receipt">Transaction Receipt Image:</label>
                    <input type="file" id="receipt" name="receipt" accept="image/*" required><br>

                    <!-- Category of Ticket (Dropdown) -->
                    <label for="ticket_category">Ticket Category:</label>
                    <select id="ticket_category" name="ticket_category" required>
                      <option value="general">General</option>
                      <option value="priority">Priority</option>
                    </select><br>

                    <!-- Submit Button -->
                    <input type="submit" value="Submit">
                  </form>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
              </div>
            </div>
          </div>
        </div><?php   } }?>
      </div>
    </div>
  </section>
  
  
  <section class="event my-5">
    <div class="container event-block p-2">
      <div class="row">
        <h1>Minhaj MIT Event</h1>
        <h2>Organizer Name: MUL</h2>
        <h4>Event Schedule</h4>
        <div class="col-md-6">
          <div class="event-date">
            <h2>Event Start Date</h2>
            <span>19/01/2024</span>
            <span></span>
          </div>
        </div>
        <div class="col-md-6">
          <div class="event-date">
            <h2>Event End Date</h2>
            <span>19/01/2024</span>
            <span></span>
          </div>
        </div>
        <div class="col-md-4">
          <div class="event-data pt-3">
            <span><img src="assets/img/normal-seat.png" alt="seat"> 300 Seats Available</span>
            <span><img src="assets/img/basic-s.png" alt="seat"> Charges: 700 Basic</span>
            <span><img src="assets/img/premium-s.png" alt="seat"> Charges: 1000 Premium</span>
          </div>
        </div>
        <div class="col-md-8">
          <div class="event-text-lines p-2">
            <p>Get ready for an extraordinary convergence of minds at Minhaj University's upcoming event, dedicated exclusively to the Master of Information Technology (MIT) students. Titled "Tech Horizons: A Journey through MIT Excellence," this symposium promises to empower minds and ignite innovation. Join us for a day filled with cutting-edge discussions, hands-on workshops, and networking opportunities that transcend boundaries. As we code, connect, and create, let's collectively unleash the future of technology. This MIT Gala is more than an event; it's a celebration of digital pioneers coming together to innovate, transform, and triumph. Don't miss the chance to elevate your tech quotient at the MIT Summit 2024—it's where the future begins.</p>
          </div>
        </div>
        <div class="col-md-12">
          <img src="assets/img/img-1.jpg" alt="" class="img-fluid">
        </div>
        <div class="col-md-12 text-center mt-4">
          <!-- Button trigger modal -->
          <button type="button" class="apply-btn" data-bs-toggle="modal" data-bs-target="#exampleModal">
            Apply Ticket
          </button>

          <!-- Modal -->
          <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Ticket Detail</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                  <h2>Ticket Submission Form</h2>

                  <form action="process_form.php" method="post" enctype="multipart/form-data">
                    <!-- Username -->
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username" required><br>

                    <!-- Email -->
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required><br>

                    <!-- Phone Number -->
                    <label for="phone">Phone Number:</label>
                    <input type="tel" id="phone" name="phone" required><br>

                    <!-- Transaction ID -->
                    <label for="transaction_id">Transaction ID:</label>
                    <input type="text" id="transaction_id" name="transaction_id" required><br>

                    <!-- Transaction Receipt Image Upload -->
                    <label for="receipt">Transaction Receipt Image:</label>
                    <input type="file" id="receipt" name="receipt" accept="image/*" required><br>

                    <!-- Category of Ticket (Dropdown) -->
                    <label for="ticket_category">Ticket Category:</label>
                    <select id="ticket_category" name="ticket_category" required>
                      <option value="general">General</option>
                      <option value="priority">Priority</option>
                    </select><br>

                    <!-- Submit Button -->
                    <input type="submit" value="Submit">
                  </form>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- FOOTER -->
  <footer class="py-3">
    <div class="footer-content">
      <div class="web-title">
        <h1>EMS</h1>
      </div>
      <div class="footer-pages">
        <h4>Useful Links</h4>
        <a href="index.php">Home</a>
        <a href="event.php">Event</a>
        <a href="contact.php">Contact</a>
        <a href="#">About Us</a>
      </div>
      <div class="contact-num">
        <h4>Contact Info</h4>
        <p>+923345432258</p>
        <p>contact@ems.pk</p>
      </div>
    </div>
  </footer>













  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>