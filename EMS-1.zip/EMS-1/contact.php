<?php 

include('common/db.php');

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $report = $_POST['report'];  
                
    $sql = "INSERT INTO `contact`(`name`, `email`, `phone`, `report`) VALUES ('$name','$email','$phone','$report')";

    $result = $conn->query($sql);
    	
  
    if ($result == true) {
        echo "<script>alert('Your Report Submitted successfully');location.href='contact.php';</script>";
    }
              
        
  else{
        echo "something wrong";
    }            
            

}


?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Contact</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="assets/css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
  <!-- Navbar Code  -->
  <div class="">
    <nav class="navbar navbar-expand-lg custom-nav">
      <div class="container">
        <a class="navbar-brand" href="index.html">EMS</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav mx-auto">
            <li class="nav-item mx-2">
              <a class="nav-link active" href="index.php">Home</a>
            </li>
            <li class="nav-item mx-2">
              <a class="nav-link" href="event.php">Events</a>
            </li>
            <li class="nav-item mx-2">
              <a class="nav-link" href="#">About Us</a>
            </li>
            <li class="nav-item mx-2">
              <a class="nav-link" href="contac.php">Contact Us</a>
            </li>
          </ul>
          <div class="">
            <a class="nav-link sign-up" href="sign-up.html">Sign Up</a>
          </div>
        </div>
      </div>
    </nav>
  </div>
  <!-- Contact Us Section -->
  <section class="my-5">
    <div class="container">
      <div class="row">
        <div class="col-md-8">
          <div class="form-div">
            <form method="POST" action="">
              <div>
                <label>Name:</label>
                <input type="text" name="name" required>
              </div>
              <div>
                <label>Email:</label>
                <input type="text" name="email" required>
              </div>
              <div>
                <label>Phone:</label>
                <input type="text" name="phone" required>
              </div>
              <div>
                <label>Report About Organizer:</label>
                <input type="textarea" name="report" required>
              </div>
              <input type="submit" name="submit">
            </form>
          </div>
        </div>
        <div class="col-md-4 contact-info">
          <div class="contact-card p-3">
            <div class="my-2">
              <span><i class="fa-solid fa-location-crosshairs"></i></span>
              <span>Minhaj University,Township</span>
            </div>
            <div class="my-2">
              <span><i class="fa-solid fa-message"></i></span>
              <span>contact@ems.pk</span>
            </div>
            <div class="my-2">
              <span><i class="fa-solid fa-phone"></i></span>
              <span>+92 343 567890</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  <!-- FOOTER -->
  <footer class="py-3">
    <div class="footer-content">
      <div class="web-title">
        <h1>EMS</h1>
      </div>
      <div class="footer-pages">
        <h4>Useful Links</h4>
        <a href="index.html">Home</a>
        <a href="event.html">Event</a>
        <a href="contact.html">Contact</a>
        <a href="About.html">About Us</a>
      </div>
      <div class="contact-num">
        <h4>Contact Info</h4>
        <p>+923345432258</p>
        <p>contact@ems.pk</p>
      </div>
    </div>
  </footer>













  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>