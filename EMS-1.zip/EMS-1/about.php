<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>About</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
	<div class="">
		<nav class="navbar navbar-expand-lg custom-nav">
			<div class="container">
				<a class="navbar-brand" href="index.php">EMS</a>
				<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbarNav">
					<ul class="navbar-nav mx-auto">
						<li class="nav-item mx-2">
							<a class="nav-link active" href="index.php">Home</a>
						</li>
						<li class="nav-item mx-2">
							<a class="nav-link" href="event.php">Events</a>
						</li>
						<li class="nav-item mx-2">
							<a class="nav-link" href="about.php">About Us</a>
						</li>
						<li class="nav-item mx-2">
							<a class="nav-link" href="contact.php">Contact Us</a>
						</li>
					</ul>
					<div class="">
						<a class="nav-link sign-up" href="sign-up.php">Sign Up</a>
					</div>
				</div>
			</div>
		</nav>
	</div>
	<div class="container">
		<div class="row my-3">
			<h1 class="text-center">Event Management System</h1>
			<h3 class="text-center">About</h3>
			<p class="about-info" style="background-color: orange;">The Event Management System is an innovative website that revolutionizes event planning and ticketing, providing a user-friendly platform for organizers and attendees alike. With its robust features and intuitive interface, the system simplifies the entire event management process from creation to ticket distribution.
				 At the heart of the system is the comprehensive admin dashboard, which empowers multiple administrators to effortlessly create, publish, and manage events. Each admin gains access to a personalized dashboard, offering a plethora of tools to customize event details, such as event name, date, time, location, description, and ticket prices. The seamless collaboration among admins ensures smooth coordination and event planning, making it an ideal solution for event management companies and businesses organizing diverse events.
			</p>
		</div>
	</div>
	 <!-- FOOTER -->
  <footer class="py-3">
    <div class="footer-content">
      <div class="web-title">
        <h1>EMS</h1>
      </div>
      <div class="footer-pages">
        <h4>Useful Links</h4>
        <a href="index.php">Home</a>
        <a href="event.php">Event</a>
        <a href="contact.php">Contact</a>
        <a href="#">About Us</a>
      </div>
      <div class="contact-num">
        <h4>Contact Info</h4>
        <p>+923345432258</p>
        <p>contact@ems.pk</p>
      </div>
    </div>
  </footer>
</body>
</html>