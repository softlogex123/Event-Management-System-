<?php include('../common/db.php');
session_start();
if($_SESSION['admin_name']){
}else{    header("location: login.php");}
include 'common/header.php';
include 'common/left-bar.php';


if (isset($_POST['submit'])) {
    $event_name = $_POST['event_name'];
    $description = $_POST['description'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $ava_seat = $_POST['ava_seat']; 
    $basic_charge = $_POST['basic_charge'];  
    $pre_charge = $_POST['pre_charge']; 
    $admin_name = $_POST['admin_name']; 

    
    $filetemp = $_FILES['file_img']['tmp_name'];
    $filename = $_FILES['file_img']['name'];
    $filetype = $_FILES['file_img']['type'];
    
    $filepath = "img/events/".$filename;
    
    move_uploaded_file($filetemp,$filepath);
    
                
    $sql = "INSERT INTO `events`(`event_name`, `description`, `start_date`, `end_date`, `ava_seat`, `basic_charge`, `pre_charge`, `admin_name`, `img`) VALUES ('$event_name','$description','$start_date','$end_date','$ava_seat','$basic_charge','$pre_charge','$admin_name','$filename')";

    $result = $conn->query($sql);
    	
  
    if ($result == true) {
        echo "<script>alert('Event added successfully!!');location.href='add_event.php';</script>";
    }
              
        
  else{
        echo "something wrong";
    }            
            

}


?>


    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-sm-12 col-xl-12">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Add Event</h6>
                    <form method="POST" action="" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="event-img" class="form-label">Event Image</label>
                            <input type="file" class="form-control" name="file_img" required>
                        </div>
                        <div class="mb-3">
                            <label for="event-title" class="form-label">Event Title</label>
                            <input type="text" class="form-control" name="event_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="event-title" class="form-label">Event Description</label>
                            <textarea name="description" class="form-control" required></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3 form-check">
                                    <label for="event-title" class="form-label">Event Start Date</label>
                                    <input type="date" class="form-control" name="start_date" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3 form-check">
                                    <label for="event-title" class="form-label">Event End Date</label>
                                    <input type="date" class="form-control" name="end_date" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3 form-check">
                                    <label for="event-title" class="form-label">Event Available Seats</label>
                                    <input type="number" class="form-control" name="ava_seat" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3 form-check">
                                    <label for="event-title" class="form-label">Event Basic Charge</label>
                                    <input type="number" class="form-control" name="basic_charge" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3 form-check">
                                    <label for="event-title" class="form-label">Event Premimum Charge</label>
                                    <input type="number" class="form-control" name="pre_charge" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3 form-check">
                                    <label for="event-title" class="form-label">Organizer Name</label>
                                    <input type="text" class="form-control" name="admin_name" Value="<?php echo $_SESSION['admin_name']; ?>" required readonly>
                                </div>
                            </div>
                        </div>
                        <div class="button">
                            <input type="submit" class="btn btn-primary" name="submit" value="Add Event"> 
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
            
            
            <?php include('common/footer.php'); ?>