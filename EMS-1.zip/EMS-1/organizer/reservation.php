<?php include('../common/db.php');
session_start();
if($_SESSION['admin_name']){
}else{    header("location: login.php");}
include 'common/header.php';
include 'common/left-bar.php';

?>


           <div class="container-fluid mt-4">
               <div class="row">
                   <div class="col-12">
                        <div class="bg-light rounded h-100 p-4">
                            <h6 class="mb-4">Reservation</h6>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">Email</th>
                                            <th scope="col">Phone No</th>
                                            <th scope="col">Transaction ID</th>
                                            <th scope="col">Receipt Image</th>
                                            <th scope="col">Ticket Category</th>
                                            <th scope="col">Reject </th>
                                            <th scope="col">Verify</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                        <?php

                                        $filter = "select * from tickets";
                                        $result = mysqli_query($conn, $filter);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {

                                         ?>
                                        
                                        <tr>
                                            <th scope="row"><?php echo $row['id']; ?></th>
                                            <td><?php echo $row['name']; ?></td>
                                            <td><?php echo $row['email']; ?></td>
                                            <td><?php echo $row['phone']; ?></td>
                                            <td><?php echo $row['trans_id']; ?></td>
                                            <td><img src="img/tickets/<?php echo $row['img']; ?>" alt="slider-img" height="50" width="50"></td>
                                            <td><?php echo $row['ticket_cat']; ?></td>
                                            <td><button class="btn-add">Reject</button></td>
                                            <td><button class="btn-add">Verify</button></td>
                                        </tr>
                                        <?php   } }?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
           </div>
            






<?php include('common/footer.php'); ?>